package com.example.dell.search;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ComunityActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);
    }
}
