package com.example.dell.search;

import android.content.Context;
import android.content.Intent;
import android.hardware.input.InputManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.TaskStackBuilder;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.time.chrono.MinguoChronology;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private Button button1;

    private Button menu1;
    private Button menu2;
    private Button menu3;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = (EditText) findViewById(R.id.search);

        //为搜索框设置点击监听事件，如果点击了则跳转到搜索界面
        editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,SearchActivity.class);
                startActivity(intent);
                finish();//2.15
            }
        });

        //获取“商城”按钮并且设置点击事件
        menu2 = (Button)findViewById(R.id.menu2);
        menu2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,StoreActivity.class);
                startActivity(intent);
                finish();//2.15 java课修改
            }
        });

        //获取“我的”按钮并设置相应的点击事件
        menu3 = (Button)findViewById(R.id.menu3);
        menu3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = Login.getInfo();
                if(str==null){
                    Intent intent = new Intent(MainActivity.this,Login.class);
                    startActivity(intent);
                    finish();//2.15
                }
                else{
                    Intent intent = new Intent(MainActivity.this,PersonalActivity.class);
                    intent.putExtra("account",str);
                    startActivity(intent);
                    finish();//2.15
                }
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        switch (id){
            case R.id.zhuye:
                Toast.makeText(MainActivity.this,"主页",Toast.LENGTH_SHORT).show();
                break;
            case R.id.shequ:
                Toast.makeText(MainActivity.this,"社区",Toast.LENGTH_SHORT).show();
                break;
            default:
        }
        return super.onOptionsItemSelected(item);
    }

}
